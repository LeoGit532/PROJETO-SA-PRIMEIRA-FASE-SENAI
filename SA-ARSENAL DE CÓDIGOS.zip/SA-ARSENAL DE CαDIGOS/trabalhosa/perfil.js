let nomeItem = document.getElementById("item")
let valorItem = document.getElementById("price")
function MostraTudoLogado(){

    // Mostra na div topo o nome do usuário logado vindo do localStorage
    document.getElementById("mostraUsuario").innerHTML = `${JSON.parse(localStorage.getItem('userLogado'))}`  
  
    // Mostra na div topo o nome do usuário logado vindo do localStorage
    document.getElementById("mostraEmail").innerHTML = `${JSON.parse(localStorage.getItem('emailLogado'))}`  

    // Mostra na div topo o nome do usuário logado vindo do localStorage
    document.getElementById("mostraSenha").innerHTML = `${JSON.parse(localStorage.getItem('senhaLogado'))}`  
    document.getElementById("textoExibido").innerHTML = `${JSON.parse(localStorage.getItem('textoSalvo'))
    
}`
mostrarTexto()
    
}
//Função para pegar o dado
function pegarTexto() {
    const texto = document.querySelector("#texto").value;
 
    localStorage.setItem("textoSalvo",  JSON.stringify(texto));

    console.log(texto);
  }

  function mostrarTexto(){
    document.getElementById("textoExibido").innerHTML = `${JSON.parse(localStorage.getItem('textoSalvo'))
  }`}

  function CadastraPlanta(){

    // Recebe do localStorage os dados de usuários    
    vetorUsuarios = JSON.parse(localStorage.getItem('usuario'))
    
    // Recebe do localStorage o usuário que está logado
    userLogado = JSON.parse(localStorage.getItem('userLogado'))

    // Percorre o vetor de usuários
    for(i=0; i < vetorUsuarios.length; i++){    

        // Verifica se o usuário é o que está logado
        if(userLogado == vetorUsuarios[i].nome){

            // Verifica se o vetor de itens do usuário logado é nulo
            if (vetorUsuarios[i].items == null) {
               
                // Recria o vetor de itens
                vetorUsuarios[i].items = []
                    
                // Chama a função que realiza o cadastro do item
                RealizaCadastroItem()

            //Caso não seja nulo
            }else{

                // Chama a função que realiza o cadastro do item
                RealizaCadastroItem()
        
            }

        }

    }

}

// Cria uma função para cadastrar o item
function RealizaCadastroItem(){

    // Cria um objeto para armazenar os dados do item
    let objetoPlanta = {
        
        // Cria propriedades do objeto item
        planta: nomeItem.value,
        qtd: valorItem.value,
        
    }

    // Adiciona o objeto criado ao vetor de item
    vetorUsuarios[i].items.push(objetoPlanta)

    // Salva no localStorage os dados já com os itens
    localStorage.setItem('usuario', JSON.stringify(vetorUsuarios))

    // Mostra mensagem de cadastro realizado
    alert("Planta cadastrada!)")

  }

// Cria uma função para listar os itens
function ListarPlantas(){

    // Recebe do localStorage os dados de usuários  
    vetorUsuarios = JSON.parse(localStorage.getItem('usuario'))

    // Recebe do localStorage o usuário que está logado
    userLogado = JSON.parse(localStorage.getItem('userLogado'))
    
    // Cria uma variável string para armazenar dados em uma lista
    let listaPlanta = ''

    // Percorre o vetor de usuários
    for (i=0; i < vetorUsuarios.length; i++){

        // Verifica o usuário logado
        if(userLogado == vetorUsuarios[i].nome){

            // Percorre o vetor de itens
            for(j=0; j < vetorUsuarios[i].items.length; j++){

                // Recebe os valores dos itens e adiciona na variável lista 
                listaPlanta += Object.values(vetorUsuarios[i].items[j]).join(' , ') + '<br>'

            }
        
        }
    
    }

    // Mostra o conteúdo da lista na div lista
    document.getElementById("lista").innerHTML = ` Suas plantas são: ` + listaPlanta 
    
}